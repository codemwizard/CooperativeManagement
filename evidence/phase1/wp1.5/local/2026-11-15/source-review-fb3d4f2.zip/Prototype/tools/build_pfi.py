# generator
print('ready')
