# generator
print('ready')
